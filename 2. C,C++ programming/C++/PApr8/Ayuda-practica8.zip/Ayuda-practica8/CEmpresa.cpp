#if !defined(_EMPRESA_CPP)
#define _EMPRESA_CPP

template<class T>
CEmpresa<T>::CEmpresa(const CEmpresa<T> &a) {
	*this = a;
}

// Operador =



// Destructor



// AgregarElemento



// GetElemento



// Operador de indexaci�n: []



#endif

#include "CCliente.h"
#include <iostream>
using namespace std;

// PREGUNTA 8: AgregarContrato de CCliente





// PREGUNTA 5: operator<< para resolver: cout << unCliente





// PREGUNTA 9: total += seguros[i]

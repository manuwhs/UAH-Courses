DROP TABLE parametro;
DROP TABLE capturaValor;
DROP TABLE categoriaEquipo;
DROP TABLE capturaImagen ;
DROP TABLE sensor;
DROP TABLE concentrador;
DROP TABLE alarma;

